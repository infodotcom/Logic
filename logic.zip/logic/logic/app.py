from flask import Flask, request, jsonify
from flask_cors import CORS
import requests
import os
import time
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__)
CORS(app)

DEEPSEEK_API_KEY = os.getenv('DEEPSEEK_API_KEY')
DEEPSEEK_API_URL = "https://api.deepseek.com/v1/chat/completions"

@app.route('/')
def home():
    return """
    <h1>LOGIC API Server</h1>
    <p>Available endpoints:</p>
    <ul>
        <li><a href="/test-deepseek">/test-deepseek</a> - Test DeepSeek connection</li>
        <li>/optimize (POST) - Prompt optimization endpoint</li>
    </ul>
    """

@app.route('/test-deepseek')
def test_deepseek():
    try:
        headers = {
            "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
            "Content-Type": "application/json"
        }
        
        response = requests.get(
            "https://api.deepseek.com/v1/models",
            headers=headers,
            timeout=5
        )
        response.raise_for_status()
        
        return jsonify({
            "status": "success",
            "models": [model['id'] for model in response.json().get('data', [])]
        })
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/optimize', methods=['POST'])
def optimize():
    try:
        data = request.json
        
        headers = {
            "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
            "Content-Type": "application/json"
        }
        
        payload = {
            "model": "deepseek-chat",
            "messages": [
                {
                    "role": "system",
                    "content": "You are LOGIC's prompt optimizer. Enhance this prompt."
                },
                {
                    "role": "user",
                    "content": data['prompt']
                }
            ],
            "temperature": 0.7
        }
        
        response = requests.post(DEEPSEEK_API_URL, headers=headers, json=payload)
        response.raise_for_status()
        
        return jsonify(response.json())
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)