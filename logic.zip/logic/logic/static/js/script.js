document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const inputPrompt = document.getElementById('inputPrompt');
    const optimizedPrompt = document.getElementById('optimizedPrompt');
    const optimizeBtn = document.getElementById('optimizeBtn');
    const copyBtn = document.getElementById('copyBtn');
    const executeBtn = document.getElementById('executeBtn');
    const styleSelect = document.getElementById('styleSelect');
    const tokenCounter = document.getElementById('tokenCounter');
    const aiOutput = document.getElementById('aiOutput');
    const outputContainer = document.getElementById('outputContainer');
    const themeSwitch = document.getElementById('themeSwitch');

    // Theme Toggle
    themeSwitch.addEventListener('change', () => {
        const theme = themeSwitch.checked ? 'dark' : 'light';
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('theme', theme);
    });

    // Load saved theme
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    themeSwitch.checked = savedTheme === 'dark';

    // Optimize Prompt
    optimizeBtn.addEventListener('click', async () => {
        if (!inputPrompt.value.trim()) {
            alert('Please enter a prompt');
            return;
        }

        optimizeBtn.disabled = true;
        optimizeBtn.textContent = 'Optimizing...';

        try {
            const response = await fetch('/optimize', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    prompt: inputPrompt.value,
                    style: styleSelect.value
                })
            });

            const data = await response.json();
            if (data.error) throw new Error(data.error);

            optimizedPrompt.value = data.optimized;
            tokenCounter.textContent = `${data.tokens} tokens`;
        } catch (error) {
            console.error('Error:', error);
            alert('Failed to optimize prompt');
        } finally {
            optimizeBtn.disabled = false;
            optimizeBtn.textContent = 'Optimize →';
        }
    });

    // Copy to Clipboard
    copyBtn.addEventListener('click', () => {
        if (!optimizedPrompt.value) {
            alert('Nothing to copy');
            return;
        }
        navigator.clipboard.writeText(optimizedPrompt.value);
        copyBtn.textContent = 'Copied!';
        setTimeout(() => {
            copyBtn.textContent = 'Copy';
        }, 2000);
    });

    // Execute Prompt
    executeBtn.addEventListener('click', async () => {
        if (!optimizedPrompt.value.trim()) {
            alert('Please optimize a prompt first');
            return;
        }

        executeBtn.disabled = true;
        executeBtn.textContent = 'Executing...';
        outputContainer.classList.remove('hidden');
        aiOutput.textContent = 'Waiting for AI response...';

        try {
            // In a real app, you'd call your backend to execute the prompt
            // This is a mock implementation
            await new Promise(resolve => setTimeout(resolve, 1500));
            aiOutput.innerHTML = `
                <h3>Sample Output</h3>
                <p>This is where the AI's response would appear. In a full implementation, 
                this would show real output from GPT-4 or other models.</p>
                <pre><code>// Code examples would be properly formatted
function example() {
    return "AI-generated content";
}</code></pre>
            `;
        } catch (error) {
            console.error('Error:', error);
            aiOutput.textContent = 'Failed to get AI response';
        } finally {
            executeBtn.disabled = false;
            executeBtn.textContent = 'Execute';
        }
    });

    // Token estimation
    inputPrompt.addEventListener('input', () => {
        const count = Math.floor(inputPrompt.value.length / 4);
        tokenCounter.textContent = `${count} tokens (estimated)`;
    });
});